"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
var client_ecs_1 = require("@aws-sdk/client-ecs");
var ecs = new client_ecs_1.ECSClient({
    region: process.env.REGION,
});
var handler = function (event) { return __awaiter(void 0, void 0, void 0, function () {
    var _i, _a, sqsRecord, s3Event, _b, _c, s3Record, key, bucket, task, command, error_1;
    return __generator(this, function (_d) {
        switch (_d.label) {
            case 0:
                _i = 0, _a = event.Records;
                _d.label = 1;
            case 1:
                if (!(_i < _a.length)) return [3 /*break*/, 8];
                sqsRecord = _a[_i];
                s3Event = JSON.parse(sqsRecord.body);
                _b = 0, _c = s3Event.Records;
                _d.label = 2;
            case 2:
                if (!(_b < _c.length)) return [3 /*break*/, 7];
                s3Record = _c[_b];
                console.log('Processing file upload', {
                    bucket: s3Record.s3.bucket.name,
                    key: s3Record.s3.object.key,
                });
                key = s3Record.s3.object.key;
                bucket = s3Record.s3.bucket.name;
                _d.label = 3;
            case 3:
                _d.trys.push([3, 5, , 6]);
                task = {
                    cluster: process.env.ECS_CLUSTER,
                    taskDefinition: process.env.ECS_TASK_DEFINITION,
                    launchType: 'FARGATE',
                    networkConfiguration: {
                        awsvpcConfiguration: {
                            subnets: process.env.SUBNETS.split(','),
                            assignPublicIp: 'ENABLED',
                        },
                    },
                    overrides: {
                        containerOverrides: [
                            {
                                name: process.env.ECS_CONTAINER_NAME,
                                environment: [
                                    {
                                        name: 'INPUT_VIDEO',
                                        value: key,
                                    },
                                    {
                                        name: 'BUCKET',
                                        value: bucket,
                                    },
                                ],
                            },
                        ],
                    },
                };
                command = new client_ecs_1.RunTaskCommand(task);
                return [4 /*yield*/, ecs.send(command)];
            case 4:
                _d.sent();
                console.log('Task submitted to ECS', task);
                return [3 /*break*/, 6];
            case 5:
                error_1 = _d.sent();
                console.error('Error submitting ECS task', error_1);
                return [3 /*break*/, 6];
            case 6:
                _b++;
                return [3 /*break*/, 2];
            case 7:
                _i++;
                return [3 /*break*/, 1];
            case 8: return [2 /*return*/];
        }
    });
}); };
exports.handler = handler;
